<?php
define("NETCAT_MODULE_OCTOPOST", "Postman");
define("NETCAT_MODULE_OCTOPOST_DESCRIPTION", "Delivery of letters to addressees");
define("NETCAT_MODULE_OCTOPOST_BUTTON_ADD", "Add");
define("NETCAT_MODULE_OCTOPOST_BUTTON_BACK", "Back");
define("NETCAT_MODULE_OCTOPOST_BUTTON_SAVE", "Save");
define("NETCAT_MODULE_OCTOPOST_MODE_ADD", "Addition");
define("NETCAT_MODULE_OCTOPOST_MODE_UPDATE", "Change");
define("NETCAT_MODULE_OCTOPOST_EVENT", "Event");
define("NETCAT_MODULE_OCTOPOST_EVENT_CHOSE", "Select event");
define("NETCAT_MODULE_OCTOPOST_ESSENCE_CHOSE", "Select the essence");
define("NETCAT_MODULE_OCTOPOST_CATALOGUE", "Site");
define("NETCAT_MODULE_OCTOPOST_SUBDIVISION", "Page");
define("NETCAT_MODULE_OCTOPOST_SUBCLASS", "Infoblock");
define("NETCAT_MODULE_OCTOPOST_CLASS", "Component");
define("NETCAT_MODULE_OCTOPOST_USER", "User");
define("NETCAT_MODULE_OCTOPOST_ALL", "All");

define("NETCAT_MODULE_OCTOPOST_RULE", "Rules");
define("NETCAT_MODULE_OCTOPOST_RULE_INDEX", "List rules");
define("NETCAT_MODULE_OCTOPOST_RULE_ADD", "Add rule");
define("NETCAT_MODULE_OCTOPOST_RULE_UPDATE", "Update rule");
define("NETCAT_MODULE_OCTOPOST_RULE_NOT_EXIST", "Have been created not one rule");

define("NETCAT_MODULE_OCTOPOST_MAIL", "Message");
define("NETCAT_MODULE_OCTOPOST_MAIL_INDEX", "List messages");
define("NETCAT_MODULE_OCTOPOST_MAIL_ADD", "Add messages");
define("NETCAT_MODULE_OCTOPOST_MAIL_UPDATE", "Update messages");
define("NETCAT_MODULE_OCTOPOST_MAIL_NOT_EXIST", "Have been created not one messages");

define("NETCAT_MODULE_OCTOPOST_SETTINGS", "Settings");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_EMAIL", "Email default");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_NAME", "Default sender name");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_SUBJECT", "Message subject by default");