<?php

class octopost{

  public
    $event = array(
    1 => "add",
    2 => "update",
    3 => "check",
    4 => "uncheck",
    5 => "drop",
    6 => "recovery"
  ),

    $essence = array(
    4 => "Message",
    5 => "Message",
    6 => "User"
  ),

    $send = true,

    $SQL = array(),
    $fields = array(),
    $Attach = array(),
    $Mail = array('Email_To', 'Email_From', 'Email_Reply', 'Name', 'Subject', 'Message');

  public $Octopost_ID, $Essence, $Catalogue_ID, $Subdivision_ID, $Class_ID, $Sub_Class_ID, $Message_ID, $User_ID;

  public function __construct(){
    $nc_core = nc_Core::get_object();
    
    $nc_data = $nc_core->db->get_results("SELECT * FROM `Octopost` WHERE `Checked` = 1 ORDER BY `Event` DESC");
    if($nc_data){
      foreach($nc_data as $rule){
        $Suffix = $SuffixSub = $Cron = '';
        // Хак из за внутренних проблем
        if($rule->Event == 5 AND $rule->Essence != 4 AND $rule->Essence != 5) $Suffix = 'Prep';
        if($rule->Essence == 5) $SuffixSub = 'Sub';
        if($rule->Cron) $Cron = 'Cron';
        //$nc_core->event->bind($this, array($this->event[$event->Event] . $this->essence[$event->Essence] . $Suffix => "event_" . $this->event[$event->Event] . $this->essence[$event->Essence] . $SuffixSub . $Cron));
        $nc_core->event->bind($this, array($this->event[$rule->Event] . $this->essence[$rule->Essence] . $Suffix => $this->event[$rule->Event] . "_" . $this->essence[$rule->Essence] . "_" . $rule->Octopost_ID . "_" . $SuffixSub . "_" . $Cron));
      }
    }
  }

  function __call($method, $val = null){
    $nc_core = nc_Core::get_object();

    $method = explode("_", $method);

    $this->Octopost_ID = $method[2];
    $this->Catalogue_ID = $val[0];
    $this->Subdivision_ID = $val[1];
    $this->Sub_Class_ID = $val[2];
    $this->Class_ID = $val[3];
    $this->Message_ID = $val[4];
    if(empty($val[1])) $this->User_ID = $val[0];
    $rule = $nc_core->db->get_row("SELECT * FROM `Octopost` WHERE `Checked` = 1 AND `Octopost_ID` = " . $this->Octopost_ID . "");
    if(($rule->Essence_ID == 0 AND ($this->Class_ID == 0 OR $this->Sub_Class_ID == 0 OR $this->User_ID == 0)) OR $rule->Essence_ID == $this->Class_ID OR $rule->Essence_ID == $this->Sub_Class_ID OR $rule->Essence_ID == $this->User_ID)
      if($method[4] == 'Cron'){
        $nc_core->db->query("INSERT INTO `Octopost_Cron` (`Octopost_ID`, `Essence_ID`, `Date`) VALUES ('" . $this->Octopost_ID . "', '" . ($this->User_ID ? $this->User_ID : $this->Message_ID) . "', '" . date("Y-m-d H:i:s", time() + 30) . "');");
      }else{
        $this->sql($this->Catalogue_ID, $this->Subdivision_ID, $this->Class_ID, $this->Sub_Class_ID, $this->Message_ID, $this->User_ID);
        $this->query();
        $this->request();
      }
  }


  // Получение списка полей
  public function sql($Catalogue_ID = null, $Subdivision_ID = null, $Class_ID = null, $Sub_Class_ID = null, $Message_ID = null, $User_ID = null){
    if($Catalogue_ID) $this->SQL["Catalogue"] = "SELECT * FROM `Catalogue` WHERE `Catalogue_ID` = " . $Catalogue_ID . "";
    if($Subdivision_ID) $this->SQL["Subdivision"] = "SELECT * FROM `Subdivision` WHERE `Subdivision_ID` = " . $Subdivision_ID . "";
    if($Sub_Class_ID) $this->SQL["Sub_Class"] = "SELECT * FROM `Sub_Class` WHERE `Sub_Class_ID` = " . $Sub_Class_ID . "";
    if($Message_ID){
      $this->SQL["Message"] = "SELECT * FROM `Message" . $Class_ID . "` WHERE `Message_ID`=" . $Message_ID . "";
      $this->Class_ID = $Class_ID;
      $this->Message_ID = $Message_ID;
    };
    if($User_ID) $this->SQL["User"] = "SELECT * FROM `User` WHERE `User_ID`" . (is_array($User_ID) ? " IN (" . implode(",", $User_ID) . ")" : "=" . $User_ID) . "";
    return $this->SQL;
  }

  // Подмена полей
  public function query(){
    $nc_core = nc_Core::get_object();

    // Цикл обработки сущностей
    foreach($this->SQL as $Essence => $Query){
      $Essence_lower = mb_strtolower($Essence);
      // Запрос на поля сущности
      $this->fields['Query'][$Essence] = $nc_core->db->get_row($Query, ARRAY_A);
      // Если сущность "Сообщение" то добавить запрос на пользователя
      if($Essence == 'Message' AND $this->fields['Query']['Message']['User_ID']) $this->sql(null, null, null, null, null, $this->fields['Query']['Message']['User_ID']);

      // Цикл обработки полей сущности
      $i = 0;
      foreach($this->fields['Query'][$Essence] as $Field_Name => $Field_Value){
        // Если сущность "Сообщение" то получить данные поля из таблицы `Field`
        if($Essence == 'Message'){
          $Field = $nc_core->db->get_row("SELECT `Field_ID`, `TypeOfData_ID`, `Format` FROM `Field` WHERE `Class_ID`=" . $this->Class_ID . " AND `Field_Name`='" . $Field_Name . "'", ARRAY_A);
        }
        if(!empty($Field)){

          // Обработать поля по типу
          switch($Field['TypeOfData_ID']){
            case 4: // Список
              $Field['Format'] = explode(":", $Field['Format']);
              $Classificator = $nc_core->db->get_row("SELECT * FROM Classificator_" . $Field['Format'][0] . " WHERE " . $Field['Format'][0] . "_ID=" . $Field_Value . "", ARRAY_A);

              array_push($this->fields['Result']['Column'], "{" . $Essence_lower . "." . $Field_Name . ".ID}", "{" . $Essence_lower . "." . $Field_Name . ".Name}", "{" . $Essence_lower . "." . $Field_Name . ".Value}");
              array_push($this->fields['Result']['Value'], $Field_Value, $Classificator[$Field['Format'][0] . "_Name"], $Classificator["Value"]);

              $Field_Value = $Classificator[$Field['Format'][0] . "_Name"];
              break;

            case 5: // Логическая переменная
              if($Field_Value == 1) $Field_Value = 'Да';
              else $Field_Value = 'Нет';
              break;

            case 6: // Файл
              $Value = explode(":", $Field_Value);
              $File_Link = nc_file_path($this->Class_ID, $this->Message_ID, $Field['Field_ID']);
              array_push($this->fields['Result']['Column'], "{" . $Essence_lower . "." . $Field_Name . ".Link}", "{" . $Essence_lower . "." . $Field_Name . ".Name}");
              array_push($this->fields['Result']['Value'], $File_Link, $Value[0]);
              break;

            case 9: // Связь с другой сущностью
              $Field['Format'] = explode(":", $Field['Format']);
              if(is_numeric($Field['Format'][0])){
                $Table = "Message";
                $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".Path}";
                $this->fields['Result']['Value'][] = nc_object_path($Field['Format'][0], $Field_Value);
                $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".URL}";
                $this->fields['Result']['Value'][] = nc_object_url($Field['Format'][0], $Field_Value);
              }else{
                $Table = $Field['Format'][0];
                switch($Field['Format'][0]){
                  case 'Subdivision':
                    $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".Path}";
                    $this->fields['Result']['Value'][] = nc_folder_path($Field_Value);
                    $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".URL}";
                    $this->fields['Result']['Value'][] = nc_folder_url($Field_Value);
                    break;
                  case 'Sub_Class':
                    $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".Path}";
                    $this->fields['Result']['Value'][] = nc_infoblock_path($Field_Value);
                    $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . ".URL}";
                    $this->fields['Result']['Value'][] = nc_infoblock_url($Field_Value);
                    break;
                  case 'User':
                    break;
                }
              }
              $bound = $nc_core->db->get_row("SELECT * FROM " . $Table . $Field['Format'][0] . " WHERE " . $Table . "_ID=" . $Field_Value . "", ARRAY_A);
              foreach($bound as $bound_Field_Name => $bound_Field_Value){
                $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . "." . $bound_Field_Name . "}";
                $this->fields['Result']['Value'][] = $bound_Field_Value;
              }
              break;

            case 10: // Множественный выбор
              $Field['Format'] = explode(":", $Field['Format']);
              $Field_Value = implode(",", array_filter(explode(",", $Field_Value)));
              $Classificator = $nc_core->db->get_results("SELECT " . $Field['Format'][0] . "_Name FROM Classificator_" . $Field['Format'][0] . " WHERE " . $Field['Format'][0] . "_ID IN(" . $Field_Value . ")", ARRAY_A);
              $Field_Value = array();
              foreach($Classificator as $row){
                $Field_Value[] = $row[$Field['Format'][0] . "_Name"];
              }
              $Field_Value = implode(", ", $Field_Value);
              break;

            case 11: // Множественная зугрузка файлов
              $Files = $nc_core->db->get_results("SELECT * FROM Multifield WHERE Field_ID=" . $Field['Field_ID'] . " AND " . $Essence . "_ID=" . $this->fields['Query'][$Essence][$i][$Essence . "_ID"] . "", ARRAY_A);
              foreach($Files as $File){
                $Field_Name = explode($Field['Field_ID'] . "/", $File['Path']);
                $Field_Value[] = $File['Path'];
              }
              $Field_Value = implode(", \n", $Field_Value);
              break;

            default:
              break;
          }
        }

        // Если встречаются запрещенные символы указывающие на взлом
        $pattern = "/(<\?)|(\?>)/";
        if(preg_match($pattern, $Field_Value))
          $Field_Value = 'Попытка взлома';

        // Записать в массив имена и значения
        $this->fields['Result']['Column'][] = "{" . $Essence_lower . "." . $Field_Name . "}";
        $this->fields['Result']['Value'][] = $Field_Value;

        if($Essence == 'Message'){
          $this->fields['Result']['Column'][] = "{" . $Field_Name . "}";
          $this->fields['Result']['Value'][] = $Field_Value;
        }

        $i++;
      }

    }

    // Добавить.Условие
    array_push($this->fields['Result']['Column'], '&quot;.(', '? &quot;', '&quot; : &quot;', '&quot;).&quot', '&#39;', '&quot;');
    array_push($this->fields['Result']['Value'], "<? if(", "){ ?>", "<? }else{ ?>", "<? } ?>", "'", '"');

    array_push($this->fields['Result']['Column'], "{subdivision.Link}");
    array_push($this->fields['Result']['Value'],
      nc_folder_path($this->fields['Query'][$Essence]["Subdivision_ID"])
    );
    array_push($this->fields['Result']['Column'], "{sub_class.Link}", "{sub_class.Link.Subscribe}");
    array_push($this->fields['Result']['Value'],
      nc_infoblock_path($this->fields['Query'][$Essence]["Sub_Class_ID"]),
      nc_infoblock_path($this->fields['Query'][$Essence]["Sub_Class_ID"], "subscribe")
    );
    array_push($this->fields['Result']['Column'], "{message.Link}", "{message.Link.Edit}", "{message.Link.Subscribe}");
    array_push($this->fields['Result']['Value'],
      nc_object_path($this->Class_ID, $this->fields['Query'][$Essence]["Message_ID"]),
      nc_object_path($this->Class_ID, $this->fields['Query'][$Essence]["Message_ID"], "edit"),
      nc_object_path($this->Class_ID, $this->fields['Query'][$Essence]["Message_ID"], "subscribe")
    );
    // Если включен модуль "Личный кабинет"
    if($nc_core->modules->get_by_keyword('auth')){
      $this->fields['Result']['Column'][] = "{user.Link}";
      $this->fields['Result']['Value'][] = nc_auth_profile_url($this->fields['Query'][$Essence]["User_ID"]);
    }

    return $this->fields;
  }

  /**
   * Получение писем и отправка
   * @param null $Octopost_ID - ID правила для отправки
   */
  public function request($Octopost_ID = null){
    $nc_core = nc_Core::get_object();

    if($Octopost_ID) $this->Octopost_ID = $Octopost_ID;
    //if(empty($Octopost_ID)) $Octopost_ID = $nc_core->db->get_var("SELECT `Octopost_ID` FROM `Octopost` WHERE " . $this->SQL);
    $Mails = array_filter($nc_core->db->get_results("SELECT * FROM `Octopost_Mail` WHERE `Octopost_ID` = " . $this->Octopost_ID . " AND `Checked` = 1", ARRAY_A));

    if(isset($Mails) AND $this->send){
      foreach($Mails as $Mail){
        $this->send($Mail);
      }
      // Не отсылать повторно
      $this->send = false;
      // Очистить свойство
      unset($this->Class_ID);
    }

  }

  /**
   * Отправка письма
   * @param $Mail - Содержимое пиьма
   */
  public function send($Mail){
    $nc_core = nc_Core::get_object();
    $system_env = $nc_core->get_settings();

    $DOCUMENT_ROOT = rtrim(getenv("DOCUMENT_ROOT"), "/\\");

    // Получить поля компонента для состовления письма по умолчанию
    $Fields = $nc_core->db->get_results("SELECT `Field_Name`, `Description` FROM `Field` WHERE `Class_ID` = " . $this->Class_ID . " ORDER BY `Priority`");
    $Mail_Default = "<p>";
    foreach($Fields as $Field){
      $Mail_Default .= "<strong>" . $Field->Description . ":</strong> {message." . $Field->Field_Name . "}<br>";
    }
    $Mail_Default .= "</p>";

    // Если тело письма пустое то использовать письмо по умолчанию
    if(empty($Mail['Message']) AND $this->Class_ID){
      $Mail['Message'] = $Mail_Default;
    }
    // Если в в теле письма обнаружена переменная {DEFAULT} то заменить ее на сообщение по умолчанию
    $Mail['Message'] = str_replace('{DEFAULT}', $Mail_Default, $Mail['Message']);

    // Сменить значение полей согласно полученным свойствам если те были переданы
    if($this->Mail['Email_To']) $Mail['Email_To'] = $this->Mail['Email_To'];
    if($this->Mail['Email_From']) $Mail['Email_From'] = $this->Mail['Email_From'];
    if($this->Mail['Email_Reply']) $Mail['Email_Reply'] = $this->Mail['Email_Reply'];
    if($this->Mail['Name']) $Mail['Name'] = $this->Mail['Name'];
    if($this->Mail['Subject']) $Mail['Subject'] = $this->Mail['Subject'];
    if($this->Mail['Message']) $Mail['Message'] = $this->Mail['Message'];

    // Подставноква значений по умолчанию если те пустые
    $octopost_settings['Email_To'] = (!empty($Mail['Email_To']) ? $Mail['Email_To'] : ($nc_core->get_settings('Email', 'octopost') ? $nc_core->get_settings('Email', 'octopost') : $system_env['SpamFromEmail']));
    $octopost_settings['Email_From'] = (!empty($Mail['Email_From']) ? $Mail['Email_From'] : ($nc_core->get_settings('Email', 'octopost') ? $nc_core->get_settings('Email', 'octopost') : $system_env['SpamFromEmail']));
    $octopost_settings['Email_Reply'] = (!empty($Mail['Email_Reply']) ? $Mail['Email_Reply'] : ($nc_core->get_settings('Email', 'octopost') ? $nc_core->get_settings('Email', 'octopost') : $system_env['SpamFromEmail']));
    $octopost_settings['Name'] = (!empty($Mail['Name']) ? $Mail['Name'] : ($nc_core->get_settings('Name', 'octopost') ? $nc_core->get_settings('Name', 'octopost') : $system_env['SpamFromName']));
    $octopost_settings['Subject'] = (!empty($Mail['Subject']) ? $Mail['Subject'] : ($nc_core->get_settings('Subject', 'octopost') ? $nc_core->get_settings('Subject', 'octopost') : $system_env['ProjectName']));

    // Подмена полей в сообщении
    $Mail['Email_To'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $octopost_settings['Email_To']);
    $Mail['Email_From'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $octopost_settings['Email_From']);
    $Mail['Email_Reply'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $octopost_settings['Email_Reply']);
    $Mail['Name'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $octopost_settings['Name']);
    $Mail['Subject'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $octopost_settings['Subject']);
    $Mail['Message'] = str_replace($this->fields['Result']['Column'], $this->fields['Result']['Value'], $Mail['Message']);

    // Обработать php код
    ob_start();
    eval(' ?>' . $Mail['Message'] . '<? ');
    $Mail['Message'] = ob_get_contents();
    ob_end_clean();

    // Отправка
    $mailer = new CMIMEMail();
    $mailer->mailbody(strip_tags($Mail['Message']), $Mail['Message']);
    $mailer->send($Mail['Email_To'], $Mail['Email_From'], $Mail['Email_Reply'], $Mail['Subject'], $Mail['Name']);
  }

}