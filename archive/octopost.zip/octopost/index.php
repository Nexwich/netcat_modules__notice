<?php
$NETCAT_FOLDER = join(strstr(__FILE__, "/") ? "/" : "\\", array_slice(preg_split("/[\/\\\]+/", __FILE__), 0, -4)) . (strstr(__FILE__, "/") ? "/" : "\\");
include_once($NETCAT_FOLDER . "vars.inc.php");
require_once($MODULE_FOLDER . "trademan/admin.inc.php");
require_once($ADMIN_FOLDER . "function.inc.php");

require_once($ADMIN_FOLDER . "modules/ui.php");
$UI_CONFIG = new ui_config_module('trademan');

if(is_file($MODULE_FOLDER . "trademan/" . MAIN_LANG . ".lang.php")){
  require_once($MODULE_FOLDER . "trademan/" . MAIN_LANG . ".lang.php");
}else{
  require_once($MODULE_FOLDER . "trademan/en.lang.php");
}

$nc_core = nc_Core::get_object();


$action = 'index';

$perm->ExitIfNotAccess(NC_PERM_MODULE, 0, 0, 0, 1);
$MODULE_VARS = $nc_core->modules->get_module_vars();
$system_env = $nc_core->get_settings();
$module_settings = $nc_core->modules->get_by_keyword('trademan');

global $UI_CONFIG;
$UI_CONFIG->actionButtons[] = array(
  "id" => "submit",
  "caption" => NETCAT_MODULE_TRADEMAN_BUTTON_ADD,
  "action" => "urlDispatcher.load('#module.trademan.add')",
  "align" => "left"
);

if(!empty($Status['Message'])) nc_print_status($Status['Message'].$SQL, $Status['Status']);

// Запрос на получение поставщиков
$nc_data = $nc_core->db->get_results("SELECT * FROM `Trademan` ORDER BY `Priority` DESC", ARRAY_A);

BeginHtml(NETCAT_MODULE_TRADEMAN, 'trademan', "http://" . $DOC_DOMAIN . "/settings/modules/trademan/");
?>
  <link rel="stylesheet" href="styles.css"/>

  <script type="text/javascript" src="application.js"></script>

  <div id="nc_trademan_wrapper">
    <?
    // Если найдены правила
    if($nc_data){
      ?>
      <table class="nc-table nc--wide nc--striped nc--bordered nc--hovered">
        <thead>
        <tr>
          <th class="nc--compact">&nbsp;</th>
          <th class="nc--compact">&nbsp;</th>
          <th class="nc--compact">&nbsp;</th>
          <th class="nc--compact">&nbsp;</th>
          <th class="nc--compact">&nbsp;</th>
          <th class="nc--compact">&nbsp;</th>
          <? foreach($TrademanAdmin->Fields as $Field){ ?>
            <? if($Field['InTableView'] == 1){ ?>
              <th><?= $Field['Description'] ?></th><? } ?>
          <? } ?>
          <th class="nc--compact">&nbsp;</th>
        </tr>
        </thead>
        <tbody>
        <?
        // Цикл. Вывод правил
        foreach($nc_data as $Message){
          ?>
          <tr>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan<? if($Message['Checked'] == 1){ ?>.unchecked<? }else{ ?>.checked<? } ?>(<?= $Message['Trademan_ID'] ?>)"
                 class="nc-label<? if($Message['Checked'] == 1){ ?> nc--green<? }else{ ?> nc--red<? } ?>"
                ><? if($Message['Checked'] == 1){ ?>Вкл<? }else{ ?>Выкл<? } ?></a>
            </td>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.update(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--edit"></i></a>
            </td>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.sync.add(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--edit"></i></a>
            </td>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.update(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--edit"></i></a>
            </td>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.update(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--edit"></i></a>
            </td>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.update(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--file-add"></i></a>
            </td>
            <? foreach($TrademanAdmin->Fields as $Field){ ?>
              <? if($Field['InTableView'] == 1){ ?>
                <td><?= $Message[$Field['Field_Name']] ?></td><? } ?>
            <? } ?>
            <td>
              <a target="_top" href="/netcat/admin#module.trademan.drop(<?= $Message['Trademan_ID'] ?>)"><i class="nc-icon nc--remove"></i></a>
            </td>
          </tr>
        <?
        }
        ?>
        </tbody>
      </table>
    <?
    }else{
      nc_print_status("Пока еще нет не одного поставщика", "info");
    }
    ?>
  </div>
<? EndHtml(); ?>