urlDispatcher.addRoutes({
  'module.octopost':NETCAT_PATH + 'modules/octopost/admin.php',

  'module.octopost.settings':NETCAT_PATH + 'modules/octopost/admin/?controller=settings&action=index',

  'module.octopost.rule':NETCAT_PATH + 'modules/octopost/admin.php',
  // Действия
  'module.octopost.rule.add':NETCAT_PATH + 'modules/octopost/admin/?controller=rule&action=add',
  'module.octopost.rule.update':NETCAT_PATH + 'modules/octopost/admin/?controller=rule&action=update&Octopost_ID=%1',
  'module.octopost.rule.checked':NETCAT_PATH + 'modules/octopost/admin/?controller=rule&action=checked&Octopost_ID=%1',
  'module.octopost.rule.unchecked':NETCAT_PATH + 'modules/octopost/admin/?controller=rule&action=unchecked&Octopost_ID=%1',
  'module.octopost.rule.drop':NETCAT_PATH + 'modules/octopost/admin/?controller=rule&action=drop&Octopost_ID=%1',

  'module.octopost.mail':NETCAT_PATH + 'modules/octopost/admin.php',
  // Действия
  'module.octopost.mail.add':NETCAT_PATH + 'modules/octopost/admin/?controller=mail&action=add&Octopost_ID=%1',
  'module.octopost.mail.update':NETCAT_PATH + 'modules/octopost/admin/?controller=mail&action=update&Octopost_Mail_ID=%1',
  'module.octopost.mail.checked':NETCAT_PATH + 'modules/octopost/admin/?controller=mail&action=checked&Octopost_Mail_ID=%1',
  'module.octopost.mail.unchecked':NETCAT_PATH + 'modules/octopost/admin/?controller=mail&action=unchecked&Octopost_Mail_ID=%1',
  'module.octopost.mail.drop':NETCAT_PATH + 'modules/octopost/admin/?controller=mail&action=drop&Octopost_Mail_ID=%1'
});