<?php
define("NETCAT_MODULE_OCTOPOST", "Почтовые уведомления");
define("NETCAT_MODULE_OCTOPOST_DESCRIPTION", "Настройка почтовых уведомлений по событиям и сущностям");
define("NETCAT_MODULE_OCTOPOST_BUTTON_ADD", "Добавить");
define("NETCAT_MODULE_OCTOPOST_BUTTON_BACK", "Назад");
define("NETCAT_MODULE_OCTOPOST_BUTTON_SAVE", "Сохранить");
define("NETCAT_MODULE_OCTOPOST_MODE_ADD", "Добавление");
define("NETCAT_MODULE_OCTOPOST_MODE_UPDATE", "Изменение");
define("NETCAT_MODULE_OCTOPOST_EVENT", "Событие");
define("NETCAT_MODULE_OCTOPOST_EVENT_CHOSE", "Выберите событие");
define("NETCAT_MODULE_OCTOPOST_ESSENCE_CHOSE", "Выберите сущность");
define("NETCAT_MODULE_OCTOPOST_CATALOGUE", "Сайт");
define("NETCAT_MODULE_OCTOPOST_SUBDIVISION", "Раздел");
define("NETCAT_MODULE_OCTOPOST_SUBCLASS", "Инфоблок");
define("NETCAT_MODULE_OCTOPOST_CLASS", "Компонент");
define("NETCAT_MODULE_OCTOPOST_USER", "Пользователь");
define("NETCAT_MODULE_OCTOPOST_ALL", "Любой");

define("NETCAT_MODULE_OCTOPOST_RULE", "Правила");
define("NETCAT_MODULE_OCTOPOST_RULE_INDEX", "Список правил");
define("NETCAT_MODULE_OCTOPOST_RULE_ADD", "Добавление правила");
define("NETCAT_MODULE_OCTOPOST_RULE_UPDATE", "Изменение правила");
define("NETCAT_MODULE_OCTOPOST_RULE_NOT_EXIST", "Не созданно не одного правила");

define("NETCAT_MODULE_OCTOPOST_MAIL", "Письмо");
define("NETCAT_MODULE_OCTOPOST_MAIL_INDEX", "Список писем");
define("NETCAT_MODULE_OCTOPOST_MAIL_ADD", "Добавление письма");
define("NETCAT_MODULE_OCTOPOST_MAIL_UPDATE", "Изменение письма");
define("NETCAT_MODULE_OCTOPOST_MAIL_NOT_EXIST", "Не созданно не одного письма");

define("NETCAT_MODULE_OCTOPOST_SETTINGS", "Настройки");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_EMAIL", "Email по умолчанию");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_NAME", "Имя отправителя по умолчанию");
define("NETCAT_MODULE_OCTOPOST_SETTINGS_SUBJECT", "Тема письма по умолчанию");