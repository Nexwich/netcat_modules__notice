(function($){
  $(function(){

    var variables, chosen,
      select = $(".chosen, .chosen-select"),
      wrapper = $('#octopost_wrapper'),
      field_Essence = $('[name=f_Essence]'),
      field_Event = $('[name=f_Event]'),

      lang = {
        "INSERT_VARIABLES":"Вставить свойство..."
      };

    $.ajax({
      url:'/netcat/modules/octopost/admin/index.php',
      type:'GET',
      dataType:'json',
      data:{controller:'select', action:'json', Octopost_ID:$('[name=f_Octopost_ID]').val()},
      success:function(response){
        variables = response;
      }
    });

    if($('.no_cm').length){
      CKEDITOR.plugins.add('MailTemplateVariables', {
        requires:['richcombo'],
        init:function(editor){
          editor.ui.addRichCombo('MailTemplateVariables', {
            label:lang.INSERT_VARIABLES,
            title:lang.INSERT_VARIABLES,
            voiceLabel:lang.INSERT_VARIABLES,
            className:'insert_template_variable_combo',
            multiSelect:false,
            toolbar:'mailtoolbar',
            panel:{
              attributes:{'aria-label':''},
              css:[editor.config.contentsCss, CKEDITOR.skin.getPath('editor')],
              voiceLabel:lang.INSERT_VARIABLES
            },
            init:function(){
              for(var groupName in variables){
                this.startGroup(groupName);
                for(var variable in variables [groupName]){
                  var caption = variables[groupName][variable];
                  this.add(variable, caption, caption);
                }
              }
            },
            onClick:function(value){
              editor.focus();
              editor.fire('saveSnapshot');
              editor.insertHtml(value);
              editor.fire('saveSnapshot');
            }
          });
        }
      });
    }

    select.chosen({disable_search_threshold:10});

    // get the chosen object
    chosen = select.data('chosen');

    // Bind the keyup event to the search box input
    chosen.dropdown.find('input').on('keyup', function(e)
    {
        // if we hit Enter and the results list is empty (no matches) add the option
        if (e.which == 32 && chosen.dropdown.find('li.no-results').length > 0)
        {
            var option = $("<option>").val(this.value).text(this.value);

            // add the new option
            select.prepend(option);
            // automatically select it
            select.find(option).prop('selected', true);
            // trigger the update
            select.trigger("chosen:updated");
        }
    });

    wrapper.on('change', '[name=f_Event]', function(){
      if($(this).val() == 1 && field_Essence.val() != 3 && field_Essence.val() != 4 && field_Essence.val() != 5) field_Essence.chosen().change();
      if($(this).val() == 6) field_Essence.chosen(6).change()
    });

    wrapper.on('change', '.chosen-select', function(){
      var Sub_Class,
        Event = field_Event,
        Essence = field_Essence,
        elem = $(this),
        data = elem.data();

      if(data.sub_class) Sub_Class = true;
      if(data.resume != 1){
        $.ajax({
          url:"/netcat/modules/octopost/admin/index.php",
          type:'POST',
          data:{
            controller:'select',
            action:'select',
            Event:Event.val(),
            Essence:Essence.val(),
            ID:elem.val(),
            Sub_Class:Sub_Class
          },
          success:function(response){
            elem.parent().siblings('.next-box').html(response).find(".chosen-select").chosen();
          }
        });
      }
    })

  });
})(jQuery);

function nc_octopost_editor(inputFieldId){
  var editorConfig = {
    toolbarGroups:["mode", {"name":'tools'}, {"name":"clipboard"}, {"name":"mathjax"}, {"name":"undo"}, {"name":"find"}, {"name":"selection"}, {"name":"forms"}, {"name":"basicstyles"}, {"name":"cleanup"}, {"name":"list"}, {"name":"indent"}, {"name":"blocks"}, {"name":"align"}, {"name":"links"}, {"name":"insert"}, {"name":"styles"}, {"name":"colors"}],
    extraPlugins:'MailTemplateVariables',
    skin:'moono',
    language:'ru',
    filebrowserBrowseUrl:'/netcat/editors/ckeditor4/filemanager/index.php',
    allowedContent:true,
    entities:true,
    autoParagraph:true,
    fullPage:false,
    protectedSource:[/<\?.+?\?>/g]
  };

  if($('.no_cm').length){
    editorConfig.toolbarGroups.push({name:'mailtoolbar'});
    var ckeditor = CKEDITOR.replace(inputFieldId, editorConfig);
    $nc('#' + inputFieldId).data('ckeditor', ckeditor);
  }

}
