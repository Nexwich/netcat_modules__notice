<?php

$OCTOPOST_FOLDER = dirname(__FILE__);
require_once "$OCTOPOST_FOLDER/octopost.class.php";

$octopost = new octopost();

nc_core()->register_class_autoload_path('octopost_', "$OCTOPOST_FOLDER/classes");