<?
$OCTOPOST_FOLDER = dirname(__FILE__);

require_once "$OCTOPOST_FOLDER/add.view.php";