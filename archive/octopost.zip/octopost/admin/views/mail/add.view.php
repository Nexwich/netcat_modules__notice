<?php if(!class_exists('nc_core')){
  die;
}

$nc_core = nc_Core::get_object();

$Users = $nc_core->db->get_results("SELECT * FROM `User`", ARRAY_A);
$PermissionGroups = $nc_core->db->get_results("SELECT * FROM `PermissionGroup`");
$User_Field_Name = $nc_core->db->get_results("SELECT `Field_Name` FROM `Field` WHERE `Field_ID` IN(" . $nc_core->get_settings('User_Name', 'octopost') . ") ORDER BY FIELD(Field_ID, " . $nc_core->get_settings('User_Name', 'octopost') . ")");
?>
<link rel='stylesheet' href='<?= nc_module_path('octopost'); ?>styles.css'/>

<script type='text/javascript' src='<?= $SUB_FOLDER ?>/netcat/admin/js/chosen.jquery.min.js'></script>
<script src='<?= $SUB_FOLDER ?>/netcat/editors/ckeditor4/ckeditor.js'></script>
<script>var CKEDITOR_BASEPATH = '<?= $SUB_FOLDER ?>/netcat/editors/ckeditor4/';</script>
<script type='text/javascript' src='<?= nc_module_path('octopost'); ?>application.js'></script>

<div id='octopost_wrapper'>

  <form enctype='multipart/form-data' method='post' action='<?= nc_module_path('octopost'); ?>admin/?controller=mail&action=save'>
    <div>
      <? if($Octopost_Mail){ ?>
        <input type='hidden' name='f_Octopost_Mail_ID' value='<?= $Octopost_Mail->Octopost_Mail_ID ?>'>
        <input type='hidden' name='f_Octopost_ID' value='<?= $Octopost_Mail->Octopost_ID ?>'>
      <? }else{ ?>
        <input type='hidden' name='f_Octopost_ID' value='<?= $Octopost_ID ?>'>
      <? } ?>
    </div>

    <div>
      <table class='nc-table nc--bordered nc--striped' width='100%'>
        <?
        // Список полей
        foreach($Fields as $Field){
          if($Field['Checked'] == 1){
            $Field['Template'] = array("Prefix" => null, "Body" => null, "Suffix" => null);
            $Field['Value'] = null;

            // Получить значение
            $Field['Value'] = $Octopost_Mail->$Field['Field_Name'];
            // Создание атирбутов
            $attributes = null;
            foreach($Field['Attributes'] as $attribute => $value){
              $attributes .= " " . $attribute . "" . ($value ? "='" . $value . "'" : null) . "";
            }

            // Создать поле в зависимости от типа
            switch($Field['TypeOfData_ID']){
              case 1: // Строка
                $Field['Template']['Body'] = "<input type='text' " . ($nc_core->get_settings('SpamUseTransport', 'system') == 'Smtp' ? $Field['Field_Name']['Smtp'] . "value='" . $nc_core->get_settings('Email', 'postman') . "'" : "value='" . $Field['Value'] . "'") . " name='f_" . $Field['Field_Name'] . "' " . $attributes . ">";
                break;
              case 3: // Текстовый блок
                $Field['Template']['Body'] = "<textarea id='f_" . $Field['Field_Name'] . "' name='f_" . $Field['Field_Name'] . "' " . $attributes . ">" . $Field['Value'] . "</textarea>";
                $Field['Template']['Suffix'] = "<script type='text/javascript'>nc_octopost_editor('f_" . $Field['Field_Name'] . "')</script>";
                break;
              case 10:
                $Field['Template']['Prefix'] = "<select id='f_" . $Field['Field_Name'] . "' name='f_" . $Field['Field_Name'] . "' class='chosen-select' style='width:500px;' multiple>";
                foreach($Users as $User){
                  $Field['Template']['Body'] .= "<option value='" . $User['User_ID'] . "' " . (array_search($User->User_ID, explode(",",$Field['Value'])) !== false ? " selected" : null) . ">" . $User['User_ID'] . ".";
                  foreach($User_Field_Name as $User_Field){
                    $Field['Template']['Body'] .= $User[$User_Field->Field_Name] . " ";
                  }
                  $Field['Template']['Body'] .= "</option>";
                }
                $Field['Template']['Suffix'] = "</select>";
                break;
            }
            echo "
          <tr>
            <td style='width:170px;'><label for='f_" . $Field['Field_Name'] . "'>" . $Field['Description'] . "</label></td>
            <td>" . $Field['Template']['Prefix'] . $Field['Template']['Body'] . $Field['Template']['Suffix'] . "</td>
          </tr>
          ";
          }
        }
        ?>
      </table>
    </div>
  </form>
</div>