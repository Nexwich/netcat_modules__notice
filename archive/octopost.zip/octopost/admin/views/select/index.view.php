<?php if(!class_exists('nc_core')){
  die;
}

echo $Select;