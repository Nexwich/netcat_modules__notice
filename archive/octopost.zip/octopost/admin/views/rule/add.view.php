<?php if(!class_exists('nc_core')){
  die;
}

$nc_core = nc_Core::get_object();
?>
<link rel='stylesheet' href='<?= nc_module_path('octopost'); ?>styles.css'/>

<script type='text/javascript' src='<?= $SUB_FOLDER ?>/netcat/admin/js/chosen.jquery.min.js'></script>
<script type='text/javascript' src='<?= nc_module_path('octopost'); ?>application.js'></script>

<div id='octopost_wrapper'>

  <form enctype='multipart/form-data' method='post' action='<?= nc_module_path('octopost'); ?>admin/?controller=rule&action=save'>
    <div>
      <? if($Octopost_ID){ ?><input type='hidden' name='f_Octopost_ID' value='<?= $Octopost_ID ?>'><? } ?>
    </div>

    <div>
      <table class='nc-table nc--bordered nc--striped' width='100%'>

        <tr>
          <td class='rule' colspan='2'><?= NETCAT_MODULE_OCTOPOST_EVENT ?>:<br>

            <label><select name='f_Event' class='chosen' required='required'>
                <? foreach($Classificator['Event'] as $key => $Event){ ?>
                  <option value='<?= $key ?>'<?= ($Octopost->Event == $key ? " selected" : null) ?>><?= $Event['Name'] ?></option>
                <? } ?>
              </select></label>

            <label class="nowrap"><select name='f_Essence' class='chosen-select' required='required'>
                <? if(!$Mail){ ?>
                  <option><?= NETCAT_MODULE_OCTOPOST_ESSENCE_CHOSE ?></option>
                  <? foreach($Classificator['Essence'] as $key => $Essence){ ?>
                    <option value='<?= $key ?>'<?= ($Octopost->Essence == $key ? " selected" : null) ?>><?= $Essence['Name'] ?></option>
                  <? }
                } ?>
              </select></label>

            <span class='next-box'><?= $Select ?></span>
          </td>
        </tr>
        <tr>
          <td style="width: 170px;"><label for="f_Cron">Выслать с задержкой</label></td>
          <td><input type="checkbox" name="f_Cron" id="f_Cron" value="1"<? if($Octopost->Cron){ ?> checked<? } ?>>
          </td>
        </tr>
      </table>
    </div>
  </form>
  <?
  // Если правило есть
  if($Octopost_ID){
    // Если найдены письма
    if($Octopost_Mail){
      ?>
      <div id="nc_octopost_wrapper">

        <h2>Письма</h2>

        <table class="nc-table nc--wide nc--striped nc--bordered nc--hovered">
          <thead>
          <tr>
            <th class="nc--compact">&nbsp;</th>
            <th class="nc--compact">&nbsp;</th>
            <? foreach($Fields as $Field){ ?>
              <? if($Field['InTableView'] == 1){ ?>
                <th><?= $Field['Description'] ?></th><? } ?>
            <? } ?>
            <th class="nc--compact">&nbsp;</th>
          </tr>
          </thead>
          <tbody>
          <?
          // Цикл. Вывод правил
          foreach($Octopost_Mail as $Mail){
            ?>
            <tr>
              <td>
                <a target="_top" href="/netcat/admin/#module.octopost.mail<? if($Mail->Checked == 1){ ?>.unchecked<? }else{ ?>.checked<? } ?>(<?= $Mail->Octopost_Mail_ID ?>)"
                   class="nc-label<? if($Mail->Checked == 1){ ?> nc--green<? }else{ ?> nc--red<? } ?>"
                  ><? if($Mail->Checked == 1){ ?>Вкл<? }else{ ?>Выкл<? } ?></a>
              </td>
              <td>
                <a target="_top" href="/netcat/admin/#module.octopost.mail.update(<?= $Mail->Octopost_Mail_ID ?>)"><i class="nc-icon nc--edit"></i></a>
              </td>
              <? foreach($Fields as $Field){ ?>
                <? if($Field['InTableView'] == 1){ ?>
                  <td><?= $Mail->$Field['Field_Name'] ?></td><? } ?>
              <? } ?>
              <td>
                <a target="_top" href="/netcat/admin/#module.octopost.mail.drop(<?= $Mail->Octopost_Mail_ID ?>)"><i class="nc-icon nc--remove"></i></a>
              </td>
            </tr>
          <? } ?>
          </tbody>
        </table>

      </div>
    <?
    }else{
      nc_print_status(NETCAT_MODULE_OCTOPOST_MAIL_NOT_EXIST, "info");
    }
  }
  ?>
</div>