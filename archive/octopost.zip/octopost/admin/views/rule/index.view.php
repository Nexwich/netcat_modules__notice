<?php if(!class_exists('nc_core')){
  die;
}

$nc_core = nc_Core::get_object();
?>
<link rel="stylesheet" href="<?= nc_module_path('octopost'); ?>styles.css"/>
<script type="text/javascript" src="<?= nc_module_path('octopost'); ?>application.js"></script>

<div id="octopost_wrapper">
  <?
  // Если найдены правила
  if(!empty($Octopost)){
    ?>
    <table class="nc-table nc--wide nc--striped nc--bordered nc--hovered">
      <thead>
      <tr>
        <th class="nc--compact">&nbsp;</th>
        <th class="nc--compact">&nbsp;</th>
        <th class="nc--compact">&nbsp;</th>
        <th><?= NETCAT_MODULE_OCTOPOST_RULE_INDEX ?></th>
        <th class="nc--compact">&nbsp;</th>
      </tr>
      </thead>
      <tbody>
      <?
      // Цикл. Вывод правил
      foreach($Octopost as $Rule){
        // Получить название сущьности
        if($Rule->Essence_ID){
          switch($Rule->Essence){
            case 1:
              $Essence_Name = '<a href="/netcat/admin/#site.map(' . $Rule->Essence_ID . ')" target="_blank">' . $nc_core->catalogue->get_by_id($Rule->Essence_ID, "Catalogue_Name") . '</a>';
              break;
            case 2:
              $Essence_Name = '<a href="/netcat/admin/#subdivision.edit(' . $Rule->Essence_ID . ')" target="_blank">' . $nc_core->subdivision->get_by_id($Rule->Essence_ID, "Subdivision_Name") . '</a>';
              break;
            case 3:
              $Essence_Name = '<a href="/netcat/admin/#subclass.edit(' . $Rule->Essence_ID . ', ' . $nc_core->sub_class->get_by_id($Rule->Essence_ID, "Subdivision_ID") . ')" target="_blank">' . $nc_core->sub_class->get_by_id($Rule->Essence_ID, "Sub_Class_Name") . '</a>';
              break;
            case 4:
              $Essence_Name = '<a href="/netcat/admin/#dataclass_fs.edit(' . $Rule->Essence_ID . ')" target="_blank">' . $nc_core->component->get_by_id($Rule->Essence_ID, "Class_Name") . '</a>';
              break;
            case 5:
              $Sub_Class = $nc_core->sub_class->get_by_id($Rule->Essence_ID);
              $Class = $nc_core->component->get_by_id($Sub_Class['Class_ID']);
              $Essence_Name = '<a href="/netcat/admin/#object.list(' . $Rule->Essence_ID . ')" target="_blank">' . $Sub_Class['Sub_Class_Name'] . '</a>" ' . NETCAT_MODULE_OCTOPOST_CLASS . ': "<a href="/netcat/admin/#dataclass_fs.edit(' . $Class['Class_ID'] . ')" target="_blank">' . $Class["Class_Name"] . '</a>';
              break;
            case 6:
              $Essence_Name = '<a href="/netcat/admin/#user.edit(' . $Rule->Essence_ID . ')" target="_blank">' . $nc_core->db->get_var("SELECT `Login` FROM `User` WHERE `User_ID`=" . $Rule->Essence_ID . "") . '</a>';
              break;
          }
        }
        ?>
        <tr>
          <td>
            <a target="_top" href="<?= $SUB_FOLDER ?>/netcat/admin/#module.octopost.rule<? if($Rule->Checked == 1){ ?>.unchecked<? }else{ ?>.checked<? } ?>(<?= $Rule->Octopost_ID ?>)"
               class="nc-label<? if($Rule->Checked == 1){ ?> nc--green<? }else{ ?> nc--red<? } ?>"
              ><? if($Rule->Checked == 1){ ?>Вкл<? }else{ ?>Выкл<? } ?></a>
          </td>
          <td>
            <a target="_top" href="<?= $SUB_FOLDER ?>/netcat/admin/#module.octopost.rule.update(<?= $Rule->Octopost_ID ?>)"><i class="nc-icon nc--edit"></i></a>
          </td>
          <td>
            <a target="_top" href="<?= $SUB_FOLDER ?>/netcat/admin/#module.octopost.mail.add(<?= $Rule->Octopost_ID ?>)"><i class="nc-icon nc--file-add"></i></a>
          </td>
          <td>
            <?= $Classificator['Event'][$Rule->Event]['Name'] ?> <?= $Classificator['Essence'][$Rule->Essence]['Name'] ?> <? if($Rule->Essence_ID){ ?>"<?= $Essence_Name ?>"<? } ?>
          </td>
          <td>
            <a target="_top" href="<?= $SUB_FOLDER ?>/netcat/admin/#module.octopost.rule.drop(<?= $Rule->Octopost_ID ?>)"><i class="nc-icon nc--remove"></i></a>
          </td>
        </tr>
      <?
      }
      ?>
      </tbody>
    </table>
  <?
  }else{
    nc_print_status(NETCAT_MODULE_OCTOPOST_RULE_NOT_EXIST, "info");
  }
  ?>
</div>