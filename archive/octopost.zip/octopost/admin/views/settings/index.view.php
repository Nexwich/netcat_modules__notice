<?php if(!class_exists('nc_core')){
  die;
}

$nc_core = nc_Core::get_object();

$User_Fields = $nc_core->db->get_results("SELECT * FROM `Field` WHERE `System_Table_ID` = 3");
$User_Field_List_Active = explode(",", $nc_core->get_settings('User_Name', 'octopost'));
?>

<link rel="stylesheet" href="<?= nc_module_path('octopost'); ?>styles.css"/>
<script type='text/javascript' src='<?= $SUB_FOLDER ?>/netcat/admin/js/chosen.jquery.min.js'></script>
<script type="text/javascript">
  (function($){
    $(function(){
      $(".chosen-settings").chosen({width:'500px'});
    });
  })(jQuery);
</script>

<div id='octopost_wrapper'>
  <div>
    <form enctype='multipart/form-data' method='post' action="<?= nc_module_path('octopost'); ?>admin/?controller=settings&action=save">
      <div>
        <div><label for="f_Email"><?= NETCAT_MODULE_OCTOPOST_SETTINGS_EMAIL ?>:</label></div>
        <div>
          <input placeholder="<?= $nc_core->get_settings('SpamFromEmail', 'system') ?>" <? if($nc_core->get_settings('SpamUseTransport', 'system') == 'Smtp'){ ?> disabled="disabled"<? } ?> id="f_Email" name="f_Email" type="text" value="<?= $nc_core->get_settings('Email', 'octopost') ?>">
        </div>
      </div>
      <div>
        <div><label for="f_Name"><?= NETCAT_MODULE_OCTOPOST_SETTINGS_NAME ?>:</label></div>
        <div>
          <input placeholder="<?= $nc_core->get_settings('SpamFromName', 'system') ?>" id="f_Name" name="f_Name" type="text" value="<?= $nc_core->get_settings('Name', 'octopost') ?>">
        </div>
      </div>
      <div>
        <div><label for="f_Subject"><?= NETCAT_MODULE_OCTOPOST_SETTINGS_SUBJECT ?>:</label></div>
        <div>
          <input placeholder="<?= $nc_core->get_settings('ProjectName', 'system') ?>" id="f_Subject" name="f_Subject" type="text" value="<?= $nc_core->get_settings('Subject', 'octopost') ?>">
        </div>
      </div>
    </form>
  </div>

  <div>
    <br>Модуль "Почтовые уведомления" версия 2.0. Все права защищены.<br><br> Разработчик: «Панасин Александр»<br> Email:
    <a href="mailto:alterfall@mail.ru">alterfall@mail.ru</a><br> +7 930 723-49-90<br><br>
    <a target="_blank" href="http://1drv.ms/1CglT43">Документация по модулю</a>
    <br><a target="_blank" href="http://1drv.ms/1CglT43">
      <img src="data:image/gif;base64,R0lGODdhQgBCAIAAAP///wAAACwAAAAAQgBCAAAC/oSPqcvtD6OctNqLs968+w+G4kgywYmmqXEiKqq8ckDNL0sfc2yvU9sAAl05Is4xjCR5x8QSICwunsjcDWrtwbDNKzWY9UW12a6qKRlvv1czTiyFqKOms66MhdfCaz6Znte39yYY+IfnFffwhXan56Ro9BN5x/MoWbdH5sbVOWejqcUJ+LlTslmCgZqatOpp1+pHmekIWmmIZ+aT1neJSwRnGkoISCyVKHzxCUxputtpsVxbh3w8O4W4NWq93aaUHcu5bcyI3ej9TKoNOQj9O32rRjscSGiZjelOH6z4GH6ral0yY/ZqPaNHrh8sgTKicYtXyNu4Cv90gVs3sd1AgYOH+ARMSK2jvFMNOTIBOCKZRHflQvYg+KrbQ16oEk1Md+0kLX8e2W0oN1Ldk5bfYJa6+LLeJKOyhIpSyoupzGoWNS6cutCpVV8FY/1bWUUqpGJQXx1cdO2rnZAwo4KRBBZeXJe2XJ2t+K3m04L5iKb6Cziw4MGECxs+jDixYgQFAAA7" alt="qr"/>
    </a> <br>
    <a target="_blank" href="http://creativecommons.org/licenses/by-nd/3.0/deed.ru">Лицензия CC BY-ND 3.0</a><br><br>
  </div>
</div>