<?php

/**
 * Типовой контроллер страниц административного интерфейса модуля.
 */
abstract class octopost_admin_controller extends nc_ui_controller{

  protected $use_layout = true;
  protected $field = array();
  protected $classificator = array();
  protected $variables = array();

  /** @var  nc_netshop_admin_ui */
  protected $ui_config;

  /** @var string  Должен быть задан, или должен быть переопределён метод before_action() */
  protected $ui_config_class = null;

  protected function init(){
    $this->ui_config = new ui_config();

    $this->classificator = array(
      "Event" => array(
        0 => array("Event" => "temp", "Name" => "Черновик"),
        1 => array("Event" => "add", "Name" => "Добавление"),
        2 => array("Event" => "update", "Name" => "Изменение"),
        3 => array("Event" => "checked", "Name" => "Включение"),
        4 => array("Event" => "unchecked", "Name" => "Выключение"),
        5 => array("Event" => "drop", "Name" => "Удаление"),
        6 => array("Event" => "recovery", "Name" => "Восстановление")
      ),
      "Essence" => array(
        4 => array("Essence" => "Message", "Name" => "Сообщения в компоненте"),
        5 => array("Essence" => "Message", "Name" => "Сообщения в инфоблоке"),
        6 => array("Essence" => "User", "Name" => "Пользователя")
      )
    );

    $this->field = array(
      array(
        "Field_Name" => "Octopost_Mail_Name",
        "Description" => "Название",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 1,
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50
        )
      ),
      array(
        "Field_Name" => "Email_To",
        "Description" => "Email получателя",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 1,
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50
        )
      ),
      array(
        "Field_Name" => "Email_From",
        "Description" => "Email отправителя",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 0,
        "Smtp" => "disabled",
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50
        )
      ),
      array(
        "Field_Name" => "Email_Reply",
        "Description" => "Email для ответа",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 0,
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50
        )
      ),
      array(
        "Field_Name" => "Name",
        "Description" => "Имя отправителя",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 0,
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50
        )
      ),
      array(
        "Field_Name" => "Subject",
        "Description" => "Тема письма",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 1,
        "InTableView" => 1,
        "Attributes" => array(
          "maxlength" => 255,
          "size" => 50,
          "class" => "full-width"
        )
      ),
      array(
        "Field_Name" => "Message",
        "Description" => "Сообщение",
        "Checked" => 1,
        "NotNull" => 0,
        "TypeOfData_ID" => 3,
        "InTableView" => 0,
        "Attributes" => array(
          "cols" => 30,
          "rows" => 5,
          "class" => "no_cm"
        )
      )
    );

  }

  protected function select_subdivision($name, $value = ''){
    $nc_core = nc_Core::get_object();
    static $subs;

    if(is_array($value)) $value = $value[$name];
    if(!$subs){
      $subs = $nc_core->db->get_results("SELECT s.`Subdivision_ID` as `value`,
        CONCAT(s.`Subdivision_ID`, '. ', s.`Subdivision_Name`) as  `description`,
        c.`Catalogue_Name` as `optgroup`,
        s.`Parent_Sub_ID` as `parent`
        FROM `Catalogue` AS `c`, `Subdivision` AS `s`
        WHERE s.`Catalogue_ID` = c.`Catalogue_ID`
        ORDER BY c.`Priority`, s.`Priority` ", ARRAY_A);
    }

    $res = $this->select_options($subs, $value);
    return $res;
  }

  protected function select_component($name, $value = ''){
    $nc_core = nc_Core::get_object();
    static $classes;

    if(is_array($value)) $value = $value[$name];
    if(!$classes){
      $classes = $nc_core->db->get_results("SELECT `Class_ID` as value,
        CONCAT(`Class_ID`, '. ', `Class_Name`) as description,
        `Class_Group` as optgroup
        FROM `Class`
        WHERE `ClassTemplate` = 0
        ORDER BY `Class_Group`, `Priority`, `Class_ID`", ARRAY_A);
    }

    $res = $this->select_options($classes, $value);
    return $res;
  }

  protected function select_options(&$data, $selected_value = "", $level = 0, $current_parent = 0, $null_value = 0){

    if(!is_array($data)){
      trigger_error("nc_select_options: first parameter is not an array", E_USER_WARNING);
      return "";
    }

    $str = "";
    if(!$level){ // первый вызов функции
      if(array_key_exists('parent', $data[0])){ // перегруппировать по parent
        foreach((array) $data as $row){
          $values[$row['parent']][] = $row;
        }
      }else{ // чтобы не делить циклы для случаев с группировкой и без нее
        $values = array(&$data);
      }
    }else{ // рекурсивный вызов функции
      $values = &$data;
    }

    if($null_value){
      $str .= "<option value=\"0\">" . NETCAT_MODERATION_LISTS_CHOOSE . "</option>\n";
    }
    $optgroup = null;
    foreach((array) $values[$current_parent] as $row){
      if(!$level && $optgroup !== null && (!isset($row['optgroup']) || $optgroup != $row['optgroup'])){
        $optgroup = null;
        $str .= "</optgroup>\n";
      }
      if(!$level && $row['optgroup'] && ($optgroup != $row['optgroup'])){
        $optgroup = $row['optgroup'];
        $str .= "<optgroup label='" . $optgroup . "'>\n";
      }
      $str .= "<option " . ($row['without_cc'] ? 'style=\'color: #cccccc;\'' : '') . " value=\"" . htmlspecialchars($row['value']) . "\"" .
        ($row['value'] == $selected_value ? ' selected' : '') .
        ">" .
        str_repeat("&nbsp; &nbsp; &nbsp;", $level) .
        htmlspecialchars($row['description']) . "</option>\n";

      if($values[$row['value']]){
        $str .= $this->select_options($values, $selected_value, $level + 1, $row['value']);
      }
    }

    if($optgroup !== null){
      $str .= "</optgroup>\n";
    }

    return $str;
  }


  protected function before_action(){
    if($this->ui_config_class){
      $ui_config_class = $this->ui_config_class;
      $this->ui_config = new $ui_config_class($this->site_id, $this->current_action);
    }
  }

  protected function after_action($result){
    if(!$this->use_layout){
      return $result;
    }

    BeginHtml(NETCAT_MODULE_OCTOPOST, '', '');
    echo $result;
    EndHtml();
    return '';
  }

  protected function redirect($path = 'admin/index.php'){
    ob_clean();
    header("Location: " . nc_module_path('octopost') . $path);
    die;
  }

}