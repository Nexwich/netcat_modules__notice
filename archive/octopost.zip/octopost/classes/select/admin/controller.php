<?php


class octopost_select_admin_controller extends octopost_admin_controller{

  /** @var  nc_netshop_settings_admin_ui */
  protected $ui_config;

  protected function init(){
    parent::init();
    $this->bind('settings_save', array('octopost', 'next_action'));
  }

  /**
   * @return nc_ui_view
   */
  protected function action_select(){
    $nc_core = nc_Core::get_object();

    $Event = $nc_core->input->fetch_post('Event');
    $Essence = $nc_core->input->fetch_post('Essence');
    $Sub_Class = $nc_core->input->fetch_post('Sub_Class');
    $ID = $nc_core->input->fetch_post('ID');

    switch($Event){
      case 1: // Добавление
        switch($Essence){
          case 3: // Sub_Class
            $ID = 0;
            break;
          case 4: // Message
          case 5: // Message
            break;
          default:
            exit;
        }
        break;
      case 6: // Авторизация
        switch($Essence){
          case 6: // User
            break;
          default:
            exit;
        }
        break;
    }

    if($Sub_Class){
      $Prefix = NETCAT_MODULE_OCTOPOST_SUBCLASS;
      $data_Essence = "name='f_Essence_ID' data-resume='1'";
      $SQL = "SELECT `Sub_Class_ID` as `ID`, `Sub_Class_Name` as `Name`, `Checked` FROM `Sub_Class` WHERE `Subdivision_ID`=" . $ID . " ORDER BY `Priority`";
    }else{
      switch($Essence){
        case 5:
          $Prefix = NETCAT_MODULE_OCTOPOST_SUBDIVISION;
          $data_Essence = "data-sub_class='true'";
          $option = $this->select_subdivision('Sub');
          break;
        case 4:
          $Prefix = NETCAT_MODULE_OCTOPOST_CLASS;
          $data_Essence = "name='f_Essence_ID' data-resume='1'";
          $option = $this->select_component('Class');
          break;
        case 6:
          $Prefix = NETCAT_MODULE_OCTOPOST_USER;
          $data_Essence = "name='f_Essence_ID' data-resume='1'";
          $SQL = "SELECT `User_ID` as `ID`, `Login` as `Name`, `Checked` FROM `User` ORDER BY `PermissionGroup_ID`, `Login`";
          break;
        default:
          exit;
      }
    }

    if(!empty($SQL)) $Rows = $nc_core->db->get_results($SQL, ARRAY_A);
    if(!empty($Rows) OR !empty($option)){
      $result = "<span class='nowrap'>" . $Prefix . "<select class='chosen-select' " . $data_Essence . ">";
      if($Essence == 6) $result .= "<option value='0'>" . NETCAT_MODULE_OCTOPOST_ALL . "</option>";
      if(!empty($option)) $result .= $option;
      else
        foreach($Rows as $Row){
          $result .= "<option" . ($Row['Checked'] == 1 ? null : " class='unchecked'") . " value='" . $Row['ID'] . "'>" . $Row['ID'] . ". " . $Row['Name'] . "</option>";
        }
      $result .= "</select></span><span class='next-box'></span> ";
    }

    return $this->view('index', array(
      "Select" => $result
    ));
  }

  protected function action_json(){
    $nc_core = nc_Core::get_object();

    $this->variables = array(
      "Системные" => array(
        '".(\'Условие\' ? "Истина" : "Лож")."' => "Условие (если ? то : иначе)",
        "{PARENT}" => "Сообщение родительского письма",
        "{DEFAULT}" => "Сообщение по умолчанию"
      ),
      "Сайт" => array(
        "{catalogue.Catalogue_ID}" => "ID",
        "{catalogue.Catalogue_Name}" => "Название",
        "{catalogue.Domain}" => "Домен"
      ),
      "Раздел" => array(
        "{subdivision.Link}" => "Ссылка на раздел",
        "{subdivision.Subdivision_ID}" => "ID",
        "{subdivision.Catalogue_ID}" => "ID Сайта",
        "{subdivision.Parent_Sub_ID}" => "ID родительского раздела",
        "{subdivision.Subdivision_Name}" => "Название",
        "{subdivision.Template_ID}" => "ID макета",
        "{subdivision.ExternalURL}" => "Внешняя ссылка",
        "{subdivision.EnglishName}" => "Ключевое слово",
        "{subdivision.Hidden_URL}" => "Ссылка от корня",
        "{subdivision.Description}" => "Мета. Описание",
        "{subdivision.Keywords}" => "Мета. Ключевые слова",
        "{subdivision.Title}" => "Мета. Заголовок"
      ),
      "Инфоблок" => array(
        "{sub_class.Link}" => "Ссылка на инфоблок",
        "{sub_class.Link.Subscribe}" => "Ссылка на пподписку на инфоблок",
        "{sub_class.Sub_Class_ID}" => "ID",
        "{sub_class.Subdivision_ID}" => "ID раздела",
        "{sub_class.Class_ID}" => "ID компонента",
        "{sub_class.Sub_Class_Name}" => "Название",
        "{sub_class.EnglishName}" => "Ключевое слово"
      ),
      "Компонент" => array(
        "{message.Link}" => "Ссылка на объект на сайте",
        "{message.Link.Edit}" => "Ссылка на редактирование объекта на сайте",
        "{message.Link.Subscribe}" => "Ссылка на подписку на объект",
        "{message.Message_ID}" => "ID",
        "{message.User_ID}" => "ID пользователя",
        "{message.Subdivision_ID}" => "ID раздела",
        "{message.Sub_Class_ID}" => "ID инфоблока",
        "{message.Priority}" => "Приоритет",
        "{message.Keyword}" => "Ключевое слово",
        "{message.ncTitle}" => "Мета. Заголовок",
        "{message.ncKeywords}" => "Мета. Ключевые слова",
        "{message.ncDescription}" => "Мета. Описание",
        "{message.IP}" => "IP пользователя",
        "{message.Created}" => "Дата создания"
      ),
      "Пользователь" => array(
        "{user.Link}" => "Ссылка на объект на сайте",
        "{user.User_ID}" => "ID",
        "{user.Created}" => "Дата регистрации",
        "{user.Keyword}" => "Ключевое слово"
      )
    );

    $Octopost = $nc_core->db->get_row("SELECT `Essence`, `Essence_ID` FROM `Octopost` WHERE `Octopost_ID` = " . nc_core()->input->fetch_get('Octopost_ID') . "");

    foreach($nc_core->db->get_results("SELECT `Field_Name`, `Description` FROM `Field` WHERE `System_Table_ID` = 1 ORDER BY `Priority`") as $Filed){
      $this->variables['Сайт']["{catalogue." . $Filed->Field_Name . "}"] = $Filed->Description;
    }
    foreach($nc_core->db->get_results("SELECT `Field_Name`, `Description` FROM `Field` WHERE `System_Table_ID` = 2 ORDER BY `Priority`") as $Filed){
      $this->variables['Раздел']["{subdivision." . $Filed->Field_Name . "}"] = $Filed->Description;
    }
    foreach($nc_core->db->get_results("SELECT `Field_Name`, `Description` FROM `Field` WHERE `System_Table_ID` = 3 ORDER BY `Priority`") as $Filed){
      $this->variables['Пользователь']["{user." . $Filed->Field_Name . "}"] = $Filed->Description;
    }
    if($Octopost->Essence == 4 OR $Octopost->Essence == 5){
      $Essence_ID = ($Octopost->Essence == 4 ? $Octopost->Essence_ID : $nc_core->db->get_var("SELECT `Class_ID` FROM `Sub_Class` WHERE `Sub_Class_ID` = " . $Octopost->Essence_ID . ""));
      foreach($nc_core->db->get_results("SELECT `Field_Name`, `Description` FROM `Field` WHERE `Class_ID` = " . $Essence_ID . " ORDER BY `Priority`") as $Filed){
        $this->variables["Компонент"]["{message." . $Filed->Field_Name . "}"] = $Filed->Description;
      }
    }

    return $this->view('index', array(
      "Select" => json_encode($this->variables)
    ));
  }

  protected function after_action(){
    return true;
  }

}