<?php


class octopost_mail_admin_controller extends octopost_admin_controller{

  /** @var  nc_netshop_settings_admin_ui */
  protected $ui_config;

  protected $ui_config_class = 'octopost_mail_admin_ui';

  protected function init(){
    parent::init();
    $this->bind('settings_save', array('octopost', 'next_action'));
  }

  /**
   * @return nc_ui_view
   */
  protected function action_add(){
    $nc_core = nc_Core::get_object();

    $Octopost_ID = $nc_core->input->fetch_get('Octopost_ID');

    $this->ui_config->actionButtons[] = array(
      "id" => "back",
      "caption" => NETCAT_MODULE_OCTOPOST_RULE_UPDATE,
      "location" => "#module.octopost.rule.update(".$Octopost_ID.")",
      "align" => "left"
    );

    $this->ui_config->actionButtons[] = array(
      "id" => "submit",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_SAVE,
      "action" => "mainView.submitIframeForm('add')"
    );

    $this->field[1]['Attributes']['placeholder'] = $this->field[2]['Attributes']['placeholder'] = $this->field[3]['Attributes']['placeholder'] = $nc_core->get_settings('Email', 'octopost') ? $nc_core->get_settings('Email', 'octopost') : $nc_core->get_settings('SpamFromEmail', 'system');
    $this->field[4]['Attributes']['placeholder'] = $nc_core->get_settings('Name', 'octopost') ? $nc_core->get_settings('Name', 'octopost') : $nc_core->get_settings('SpamFromName', 'system');
    $this->field[5]['Attributes']['placeholder'] = $nc_core->get_settings('Subject', 'octopost') ? $nc_core->get_settings('Subject', 'octopost') : $nc_core->get_settings('ProjectName', 'system');

    return $this->view('add', array(
      'Octopost_ID' => $Octopost_ID,
      'Fields' => $this->field,
      'Variables' => $this->variables
    ));

  }

  protected function action_update(){
    $nc_core = nc_Core::get_object();

    $Octopost_Mail = $nc_core->db->get_row("SELECT * FROM `Octopost_Mail` WHERE `Octopost_Mail_ID` = " . nc_core()->input->fetch_get('Octopost_Mail_ID') . "");
    $Octopost_ID = $Octopost_Mail->Octopost_ID;

    $this->ui_config->actionButtons[] = array(
      "id" => "back",
      "caption" => NETCAT_MODULE_OCTOPOST_RULE_UPDATE,
      "location" => "#module.octopost.rule.update(".$Octopost_ID.")",
      "align" => "left"
    );

    $this->ui_config->actionButtons[] = array(
      "id" => "submit",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_SAVE,
      "action" => "mainView.submitIframeForm('add')"
    );

    $this->field[1]['Attributes']['placeholder'] = $this->field[2]['Attributes']['placeholder'] = $this->field[3]['Attributes']['placeholder'] = $nc_core->get_settings('Email', 'postman') ? $nc_core->get_settings('Email', 'postman') : $nc_core->get_settings('SpamFromEmail', 'system');
    $this->field[4]['Attributes']['placeholder'] = $nc_core->get_settings('Name', 'postman') ? $nc_core->get_settings('Name', 'postman') : $nc_core->get_settings('SpamFromName', 'system');
    $this->field[5]['Attributes']['placeholder'] = $nc_core->get_settings('Subject', 'postman') ? $nc_core->get_settings('Subject', 'postman') : $nc_core->get_settings('ProjectName', 'system');

    return $this->view('add', array(
      "Octopost_Mail" => $Octopost_Mail,
      'Octopost_ID' => $Octopost_ID,
      'Fields' => $this->field,
      'Variables' => $this->variables
    ));

  }

  protected function action_save(){
    $nc_core = nc_Core::get_object();

    $POST = $nc_core->input->fetch_post();
    $Octopost_Mail_ID = $POST["f_Octopost_Mail_ID"];
    if(!$Octopost_Mail_ID) $action = 'add';
    else $action = 'update';

    // SQL Запрос
    $SQL = "`Octopost_ID` = '" . $POST["f_Octopost_ID"] . "', `Octopost_Mail_Name` = '" . $POST["f_Octopost_Mail_Name"] . "', `Email_To` = '" . $POST["f_Email_To"] . "', `Email_From` = '" . $POST["f_Email_From"] . "', `Email_Reply` = '" . $POST["f_Email_Reply"] . "', `Name` = '" . $POST["f_Name"] . "', `Subject` = '" . $POST["f_Subject"] . "', `Message` = '" . $POST["f_Message"] . "'";

    switch($action){
      case 'add':
        $SQL = "INSERT INTO `Octopost_Mail` SET " . $SQL . "";
        break;

      case 'update':
        $SQL = "UPDATE `Octopost_Mail` SET " . $SQL . " WHERE `Octopost_Mail_ID` = " . $Octopost_Mail_ID . "";
        break;
    }
    // Выполнить запрос
    nc_core()->db->query($SQL);

    $this->redirect("admin/?controller=rule&action=update&Octopost_ID=" . $POST["f_Octopost_ID"] . "");
  }

  protected function action_checked(){
    $Octopost_Mail_ID = nc_core()->input->fetch_get('Octopost_Mail_ID');
    $Octopost_ID = nc_core()->db->get_var("SELECT `Octopost_ID` FROM `Octopost_Mail` WHERE `Octopost_Mail_ID` = " . $Octopost_Mail_ID . "");
    nc_core()->db->query("UPDATE `Octopost_Mail` SET `Checked` = 1 WHERE `Octopost_Mail_ID` = " . $Octopost_Mail_ID . "");
    $this->redirect("admin/?controller=rule&action=update&Octopost_ID=" . $Octopost_ID . "");
  }

  protected function action_unchecked(){
    $Octopost_Mail_ID = nc_core()->input->fetch_get('Octopost_Mail_ID');
    $Octopost_ID = nc_core()->db->get_var("SELECT `Octopost_ID` FROM `Octopost_Mail` WHERE `Octopost_Mail_ID` = " . $Octopost_Mail_ID . "");
    nc_core()->db->query("UPDATE `Octopost_Mail` SET `Checked` = 0 WHERE `Octopost_Mail_ID` = " . nc_core()->input->fetch_get('Octopost_Mail_ID') . "");
    $this->redirect("admin/?controller=rule&action=update&Octopost_ID=" . $Octopost_ID . "");
  }

  protected function action_drop(){
    $Octopost_Mail_ID = nc_core()->input->fetch_get('Octopost_Mail_ID');
    $Octopost_ID = nc_core()->db->get_var("SELECT `Octopost_ID` FROM `Octopost_Mail` WHERE `Octopost_Mail_ID` = " . $Octopost_Mail_ID . "");
    nc_core()->db->query("DELETE FROM `Octopost_Mail` WHERE `Octopost_Mail_ID`=" . nc_core()->input->fetch_get('Octopost_Mail_ID') . "");
    $this->redirect("admin/?controller=rule&action=update&Octopost_ID=" . $Octopost_ID . "");
  }

}