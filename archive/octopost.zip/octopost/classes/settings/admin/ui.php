<?php

class octopost_settings_admin_ui extends octopost_admin_ui{

  /**
   * @param int $catalogue_id
   * @param string $active_tab
   */
  public function __construct($catalogue_id, $active_tab){
    parent::__construct('settings', NETCAT_MODULE_OCTOPOST_SETTINGS);

    $this->locationHash = "module.octopost.settings";

    $this->catalogue_id = $catalogue_id;
    $this->activeTab = $active_tab;
  }

}