<?php


class octopost_settings_admin_controller extends octopost_admin_controller{

  /** @var  nc_netshop_settings_admin_ui */
  protected $ui_config;

  protected $ui_config_class = 'octopost_settings_admin_ui';

  protected function init(){
    parent::init();
    $this->bind('settings_save', array('octopost', 'next_action'));
  }

  /**
   * @return nc_ui_view
   */
  protected function action_index(){
    $this->ui_config->actionButtons[] = array(
      "id" => "submit",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_SAVE,
      "action" => "mainView.submitIframeForm('add')"
    );

    return $this->view('index', array());
  }

  protected function action_save(){
    $nc_core = nc_Core::get_object();

    $nc_core->set_settings('Email', $_POST['f_Email'], 'octopost');
    $nc_core->set_settings('Name', $_POST['f_Name'], 'octopost');
    $nc_core->set_settings('Subject', $_POST['f_Subject'], 'octopost');

    $this->redirect("admin/");
  }

}