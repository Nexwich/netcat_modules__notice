<?php


class octopost_rule_admin_controller extends octopost_admin_controller{

  /** @var  nc_netshop_settings_admin_ui */
  protected $ui_config;

  protected $ui_config_class = 'octopost_rule_admin_ui';

  protected function init(){
    parent::init();
    $this->bind('settings_save', array('octopost', 'next_action'));
  }

  /**
   * @return nc_ui_view
   */
  protected function action_index(){

    $this->ui_config->actionButtons[] = array(
      "id" => "add",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_ADD,
      "location" => "#module.octopost.rule.add",
    );

    return $this->view('index', array(
      'Octopost' => nc_core()->db->get_results("SELECT * FROM `Octopost` ORDER BY `Essence` DESC, `Essence_ID`, `Event` DESC"),
      'Classificator' => $this->classificator
    ));

  }

  /**
   * @return nc_ui_view
   */
  protected function action_add(){

    $Octopost = nc_core()->db->get_row("SELECT * FROM `Octopost` WHERE `Octopost_ID` = " . nc_core()->input->fetch_get('Octopost_ID') . "");

    // Кнопки
    $this->ui_config->actionButtons[] = array(
      "id" => "back",
      "caption" => NETCAT_MODULE_OCTOPOST_RULE_INDEX,
      "location" => "#module.octopost",
      "align" => "left"
    );
    $this->ui_config->actionButtons[] = array(
      "id" => "submit",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_SAVE,
      "action" => "mainView.submitIframeForm('add')"
    );

    return $this->view('add', array(
      "Octopost" => $Octopost,
      'Classificator' => $this->classificator,
      'Fields' => $this->field
    ));

  }

  protected function action_update(){

    $Octopost = nc_core()->db->get_row("SELECT * FROM `Octopost` WHERE `Octopost_ID` = " . nc_core()->input->fetch_get('Octopost_ID') . "");

    // Кнопки
    $this->ui_config->actionButtons[] = array(
      "id" => "back",
      "caption" => NETCAT_MODULE_OCTOPOST_RULE_INDEX,
      "location" => "#module.octopost",
      "align" => "left"
    );
    $this->ui_config->actionButtons[] = array(
      "id" => "submit",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_SAVE,
      "action" => "mainView.submitIframeForm('add')"
    );
    $this->ui_config->actionButtons[] = array(
      "id" => "add",
      "caption" => NETCAT_MODULE_OCTOPOST_BUTTON_ADD,
      "location" => "#module.octopost.mail.add(" . $Octopost->Octopost_ID . ")"
    );

    // Выпадающий список в правилах
    if(!$Octopost OR ($Octopost->Event == 1 AND ($Octopost->Essence == 1 OR $Octopost->Essence == 2 OR $Octopost->Essence == 6))){
      $result = '<span class="next-box"></span>';
    }else{
      $Recursion = $Prefix = $Prefix2 = null;
      $query = array();
      switch($Octopost->Essence){
        case 5:
          $Prefix = NETCAT_MODULE_OCTOPOST_SUBDIVISION;
          $Prefix2 = NETCAT_MODULE_OCTOPOST_SUBCLASS;
          $Recursion = nc_core()->sub_class->get_by_id($Octopost->Essence_ID, "Subdivision_ID");
          $query[1] = "";
          $query[2] = "SELECT `Sub_Class_ID` as `ID`, `Sub_Class_Name` as `Name`, `Checked` FROM `Sub_Class` WHERE `Subdivision_ID` = " . $Recursion . " ORDER BY `Priority`";
          $option[1] = $this->select_subdivision('Sub', $Recursion);
          break;
        case 4:
          $Prefix = NETCAT_MODULE_OCTOPOST_CLASS;
          $query[1] = "";
          $option[1] = $this->select_component('Class', $Octopost->Essence_ID);
          break;
        case 6:
          $Prefix = NETCAT_MODULE_OCTOPOST_USER;
          $query[1] = "SELECT `User_ID` as `ID`, `Login` as `Name`, `Checked` FROM `User` ORDER BY `PermissionGroup_ID`, `Login`";
          break;
      }
      $query_count = count($query);
      $result = '';
      foreach($query as $key => $SQL){
        if(!empty($SQL)) $Rows = nc_core()->db->get_results($SQL);
        if(!empty($Rows) OR !empty($option[$key])){
          $result .= "
          <span class='next-box'>
          <span class='nowrap'>
            <label for='f_" . $key . "'>" . ($Prefix2 && $query_count == $key ? $Prefix2 : $Prefix) . "</label>
            <select id='f_" . $key . "' class='chosen-select' " . ($query_count == $key ? "name='f_Essence_ID' data-resume='1'" : "data-sub_class='true'") . ">";
            if($Octopost->Essence == 6) $result .= "<option value='0'>" . NETCAT_MODULE_OCTOPOST_ALL . "</option>";
          if(!empty($option[$key])) $result .= $option[$key];
          else
            foreach($Rows as $Row){
              $result .= "<option " . (!$Row->Checked ? " class='unchecked'" : null) . " value='" . $Row->ID . "'" . ($Octopost->Essence_ID == $Row->ID || $Recursion == $Row->ID ? " selected" : null) . ">" . $Row->ID . ". " . $Row->Name . "</option>";
            }
          $result .= "</select></span>";
        }
      }
      for($i = 0; $i < $query_count; $i++){
        $result .= "</span>";
      }
    }

    return $this->view('add', array(
      "Octopost" => $Octopost,
      'Classificator' => $this->classificator,
      'Select' => $result,
      'Fields' => $this->field,
      'Octopost_Mail' => nc_core()->db->get_results("SELECT * FROM `Octopost_Mail` WHERE `Octopost_ID` = " . $Octopost->Octopost_ID . "")
    ));

  }

  protected function action_save(){
    $Octopost_ID = nc_core()->input->fetch_post('f_Octopost_ID');
    if(!$Octopost_ID) $action = 'add';
    else $action = 'update';

    // SQL Запрос
    $SQL = "`Event` = '" . $_POST["f_Event"] . "', `Essence` = '" . $_POST["f_Essence"] . "', `Essence_ID` = '" . $_POST["f_Essence_ID"] . "', `Cron` = '" . $_POST["f_Cron"] . "'";

    switch($action){
      case 'add':
        $SQL = "INSERT INTO `Octopost` SET " . $SQL . "";
        break;

      case 'update':
        $SQL = "UPDATE `Octopost` SET " . $SQL . " WHERE `Octopost_ID` = " . $Octopost_ID . "";
        break;
    }
    // Выполнить запрос
    nc_core()->db->query($SQL);

    // Редирект обратно в объект
    if(!$Octopost_ID) $Octopost_ID = nc_core()->db->insert_id;
    $this->redirect("admin/?controller=rule&action=update&Octopost_ID=" . $Octopost_ID . "");
  }

  protected function action_checked(){
    nc_core()->db->query("UPDATE `Octopost` SET `Checked` = 1 WHERE `Octopost_ID` = " . nc_core()->input->fetch_get('Octopost_ID') . "");
    $this->redirect();
  }

  protected function action_unchecked(){
    nc_core()->db->query("UPDATE `Octopost` SET `Checked` = 0 WHERE `Octopost_ID` = " . nc_core()->input->fetch_get('Octopost_ID') . "");
    $this->redirect();
  }

  protected function action_drop(){
    nc_core()->db->query("DELETE FROM `Octopost` WHERE `Octopost_ID`=" . nc_core()->input->fetch_get('Octopost_ID') . "");
    nc_core()->db->query("DELETE FROM `Octopost_Mail` WHERE `Octopost_ID`=" . nc_core()->input->fetch_get('Octopost_ID') . "");
    $this->redirect();
  }

}