<?

$NETCAT_FOLDER = join(strstr(__FILE__, "/") ? "/" : "\\", array_slice(preg_split("/[\/\\\]+/", __FILE__), 0, -4)) . (strstr(__FILE__, "/") ? "/" : "\\");
include_once($NETCAT_FOLDER . "vars.inc.php");
require($INCLUDE_FOLDER . "index.php");
require_once($MODULE_FOLDER . "octopost/octopost.class.php");

$Octopost = new Octopost();
$nc_core = nc_Core::get_object();

// Получение всех Крон событий
$nc_data = $nc_core->db->get_results("SELECT *  FROM `Octopost_Cron` WHERE `Date` <= NOW()");
foreach($nc_data as $Cron){
  $Octopost_item = $nc_core->db->get_row("SELECT * FROM `Octopost` WHERE `Octopost_ID` = " . $Cron->Octopost_ID . " AND `Checked` = 1");
  // Выбрать поля согласно сущности
  switch($Octopost_item->Essence){
    case 4: // Компонент
      $Class_ID = $Octopost_item->Essence_ID;
      $Message = $nc_core->db->get_row("SELECT `Subdivision_ID`, `Sub_Class_ID`, FROM `Message" . $Class_ID . "` WHERE `Message_ID` = " . $Cron->Essence_ID . " LIMIT 1");
      $Catalogue_ID = $nc_core->db->get_var("SELECT `Catalogue_ID` FROM `Subdivision` WHERE `Subdivision_ID` = " . $Message->Subdivision_ID . " LIMIT 1");

      $Octopost->sql($Catalogue_ID, $Message->Subdivision_ID, $Class_ID, $Message->Sub_Class_ID, $Cron->Essence_ID);
      break;
    case 5:
      $Class_ID = $nc_core->db->get_var("SELECT `Class_ID` FROM `Sub_Class` WHERE `Sub_Class_ID` = " . $Octopost_item->Essence_ID . " LIMIT 1");
      $Message = $nc_core->db->get_row("SELECT `Subdivision_ID`, `Sub_Class_ID` FROM `Message" . $Class_ID . "` WHERE `Message_ID` = " . $Cron->Essence_ID . " LIMIT 1");
      $Catalogue_ID = $nc_core->db->get_var("SELECT `Catalogue_ID` FROM `Subdivision` WHERE `Subdivision_ID` = " . $Message->Subdivision_ID . " LIMIT 1");

      $Octopost->sql($Catalogue_ID, $Message->Subdivision_ID, $Class_ID, $Message->Sub_Class_ID, $Cron->Essence_ID);
      break;
    case 6: // Пользователь
      $Octopost->sql(null, null, null, null, null, $Cron->Essence_ID);
      break;
  }
  $Octopost->Class_ID = $Class_ID;
  $Octopost->query();
  $Octopost->request($Cron->Octopost_ID);

  $nc_core->db->query("DELETE FROM `Octopost_Cron` WHERE `Octopost_Cron_ID` = ".$Cron->Octopost_Cron_ID."");
}
