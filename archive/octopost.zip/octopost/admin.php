<?php
chdir('admin/');

require_once 'admin/index.php';
?>